## Project Scope Statement - PMUPM


*Johnny Solano - CMPA Week 03*

*January 20, 2026*


- **Project Purpose:** This project is the first of the semester that not only shows my abilities with HTML, but also how
well I can follow instructions based on PMUPM's guidelines in chapter 3.
- **Description:** The HTML file is going to include a head, title, body alongside 2 paragraphs and utilize a bulleted list which further details my hobbies. Where as the paragraphs will be my goals for my career. Ending with a hyperlink to Github.
- **Desired Results:** Deliver my assignment on time despite all trials thus far, while also maintaining 100 points and furthering what I already know of HTML.
- **Exclusions:** I do not need to pretty anything up or add to much to this project but rather stick to the fundamentals asked of me.